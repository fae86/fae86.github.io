import xbmcaddon

'''#####-----Build File-----#####'''
buildfile = 'https://nolotires.net/txts/builds.xml'

'''#####-----Notifications File-----#####'''
notify_url  = 'https://nolotires.net/txts/notify.txt'

'''#####-----Excludes-----#####'''
excludes  = ['plugin.video.whatever']